import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FilterService {

url="http://localhost:7000/api/";
  constructor(private http:HttpClient) { }

filterMain(data)
  	{
  		return this.http.post(this.url+'filter_main',data)
  	}

}
