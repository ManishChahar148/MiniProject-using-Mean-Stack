import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule}  from '@angular/common/http';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './pages/home/home.component';
import { LoginComponent } from './pages/login/login.component';
import { RegisterComponent } from './pages/register/register.component';
import { MainComponent } from './pages/main/main.component';
import { CarsComponent } from './pages/forms/cars/cars.component';
import { BikesComponent } from './pages/forms/bikes/bikes.component';
import { MobilesComponent } from './pages/forms/mobiles/mobiles.component';
import { PreviewComponent } from './pages/preview/preview.component';
import { FooterComponent } from './pages/footer/footer.component';
import { MyadsComponent } from './pages/myads/myads.component';
import { ProfileComponent } from './pages/profile/profile.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    RegisterComponent,
    MainComponent,
    CarsComponent,
    BikesComponent,
    MobilesComponent,
    PreviewComponent,
    FooterComponent,
    MyadsComponent,
    ProfileComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
      
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
