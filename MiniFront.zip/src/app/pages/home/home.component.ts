import { Component, OnInit } from '@angular/core';
import {CategoryService} from 'src/app/services/category.service';
import {FormGroup,FormBuilder,Validators} from '@angular/forms';
import {Router} from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private catser:CategoryService, private fb:FormBuilder,private router:Router) { }
categoryForm:FormGroup;

resData;
userName;
userEmail;  
regName;  
  ngOnInit() {
      this.validate()

      this.userName="Login";
      this.regName="/Register"
     if(localStorage.getItem('loginStat')=="true")
      {
        this.userName=localStorage.getItem('username');
        this.userEmail=localStorage.getItem('email');
        this.regName="";
      }

      this.catser.getCat()
      .subscribe(res=>{
          console.log(res);
          this.resData=res;
          this.resData=this.resData.cdata;
      })
  }


  validate()
    {
      this.categoryForm = this.fb.group(
      {
        'category':['',Validators.required]
      })
    }

  selectCategory()
    {
      let catName=this.categoryForm.controls.category.value;
      console.log(catName)
      if(catName == 'cars')
          this.router.navigate(["/cars"])
      else if(catName == 'bikes')
          this.router.navigate(["/bikes"])

    }

    logout()
      {
        localStorage.removeItem('username')
        localStorage.removeItem('loginStat')
        localStorage.removeItem('email')
        localStorage.removeItem('mobile')
        location.reload()
      }

}
